import java.awt.*;
public class Main {
    public static void main(String[] args) {
       coche miCoche = new coche();
       miCoche.incremento();
       System.out.println(miCoche.puertas);
    }
    }
class coche{
    public int puertas = 4;
    public void incremento() {
        this.puertas++;
    }
}
